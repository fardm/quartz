---
🏋️‍♂️exercise: false
📚reading: 0
📱social: 0
date: <% tp.file.title %>
shamsi: "{{این روز}}"
tags:
  - journal
---
# {{این روز هفته}}

