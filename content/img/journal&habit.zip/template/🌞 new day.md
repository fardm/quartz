---
🏋️‍♂️exercise: false
📚reading: 0
🌎English: 0
🎨drawing: 0
🍅pomodoro: 0
📱social: 
date: <% tp.file.title %>
shamsi: "{{این روز}}"
tags:
  - journal
---
