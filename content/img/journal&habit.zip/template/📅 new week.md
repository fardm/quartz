
# 📅 پیگیری عادت

```dataview
Table without ID
	file.link as Date,
	choice(🏋️‍♂️exercise=false, "⬜", "✅") as 🏋️,
	choice(📚reading=0, "⬜", "✅") as 📚,
	choice(🎨drawing=0, "⬜", "✅") as 🎨,
	choice(🌎English=0, "⬜", "✅") as 🌎
FROM #journal
WHERE file.name >= ("شروع") AND file.name <= ("پایان")
SORT file.link Asc
```



# 🍅 پومودورو

``` tracker
searchType: frontmatter
searchTarget: 🍅pomodoro
startDate: شروع
endDate: پایان
folder: journal
aspectRatio: 18:9
bar:
	title: " "
	xAxisLabel: " "
	yAxisLabel: " "
	yMin: 20
	yMax: 0
	barColor: "#ffa43d"
``` 
```tracker
searchType: frontmatter
searchTarget: 🍅pomodoro
startDate: شروع
endDate: پایان
folder: journal
summary:
    template: "🔘 جمع کل: ‌ ‌{{sum()}}\n🔺 بیشترین: ‌ ‌{{max()}}\n🔻 کمترین: ‌ ‌{{min()}}\n📈 میانگین: ‌ ‌{{average()}}"
```


‌‌
# 📱 سوشال مدیا

``` tracker
searchType: frontmatter
searchTarget: 📱social
startDate: شروع
endDate: پایان
folder: journal
aspectRatio: 18:9
bar:
    title: " "
    xAxisLabel: " "
    yAxisLabel: " "
	yMin: 8
	yMax: 0
	barColor: "#63b2f5"
```

```tracker
searchType: frontmatter
searchTarget: 📱social
startDate: شروع
endDate: پایان
folder: journal
summary:
    template: "🔘  جمع کل: ‌ ‌{{sum()}} ساعت\n🔺 بیشترین: ‌ ‌{{max()}} ساعت\n🔻 کمترین: ‌ ‌{{min()}} ساعت\n📈 میانگین: ‌ ‌{{average()}} ساعت"
```

