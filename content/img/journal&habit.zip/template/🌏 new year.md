# 💪 ورزش
```contributionGraph
title: " "
graphType: default
dateRangeValue: 180
dateRangeType: FIXED_DATE_RANGE
startOfWeek: "6"
showCellRuleIndicators: true
titleStyle:
  textAlign: center
  fontSize: 15px
  fontWeight: normal
dataSource:
  type: PAGE
  value: "#journal"
  dateField:
    type: FILE_NAME
    value: date
  countField:
    type: PAGE_PROPERTY
    value: 🏋️‍♂️exercise
fillTheScreen: true
enableMainContainerShadow: false
fromDate: شروع
toDate: پایان
cellStyleRules:
  - id: default_b
    color: "#64da7aff"
    min: 1
    max: 2
cellStyle:
  minHeight: 15px
  borderRadius: ""

```
```tracker
searchType: frontmatter
searchTarget: 🏋️‍♂️exercise
startDate: شروع
endDate: پایان
folder: journal
summary:
    template: "✅  جمع کل روزهایی که ورزش کردم: ‌ ‌{{sum()}}روز"
```
‌
‌
‌
# 🍅 پومودورو
```contributionGraph
title: ""
graphType: default
dateRangeValue: 180
dateRangeType: FIXED_DATE_RANGE
startOfWeek: "6"
showCellRuleIndicators: true
titleStyle:
  textAlign: center
  fontSize: 15px
  fontWeight: normal
dataSource:
  type: PAGE
  value: "#journal"
  dateField:
    type: FILE_NAME
    value: date
  countField:
    type: PAGE_PROPERTY
    value: 🍅pomodoro
fillTheScreen: true
enableMainContainerShadow: false
fromDate: شروع
toDate: پایان
cellStyleRules:
  - id: Halloween_a
    color: "#fdd577"
    min: 1
    max: "5"
  - id: Halloween_b
    color: "#faaa53"
    min: "5"
    max: "10"
  - id: Halloween_c
    color: "#f07c44"
    min: "10"
    max: "15"
  - id: Halloween_d
    color: "#d94e49"
    min: "15"
    max: "999"
cellStyle:
  minHeight: 15px

```
```tracker
searchType: frontmatter
searchTarget: 🍅pomodoro
startDate: شروع
endDate: پایان
folder: journal
summary:
    template: "🔘  جمع کل: ‌ ‌{{sum()}} \n🔺 بیشترین: ‌ ‌{{max()}}\n🔻 کمترین: ‌ ‌{{min()}}\n📈 میانگین: ‌ ‌{{average()}}"
```
‌
> [!quote]- نمودار
> 
> ``` tracker
> searchType: frontmatter
> searchTarget: 🍅pomodoro
> startDate: شروع
> endDate: پایان
> folder: journal
> aspectRatio: 18:9
> bar:
>     title: " "
>     xAxisLabel: " "
>     yAxisLabel: " "
> 	yMin: 20
> 	yMax: 0
> 	barColor: "#ffa43d"
> ``` 
> ‌

```contributionGraph
title: " مطالعه 📚"
graphType: default
dateRangeValue: 180
dateRangeType: FIXED_DATE_RANGE
startOfWeek: "6"
showCellRuleIndicators: true
titleStyle:
  textAlign: center
  fontSize: 18px
  fontWeight: normal
dataSource:
  type: PAGE
  value: "#journal"
  dateField:
    type: FILE_NAME
    value: date
  countField:
    type: PAGE_PROPERTY
    value: 📚reading
fillTheScreen: true
enableMainContainerShadow: false
fromDate: شروع
toDate: پایان
cellStyleRules:
  - id: Halloween_a
    color: "#fdd577"
    min: 1
    max: "5"
  - id: Halloween_b
    color: "#faaa53"
    min: "5"
    max: "10"
  - id: Halloween_c
    color: "#f07c44"
    min: "10"
    max: "15"
  - id: Halloween_d
    color: "#d94e49"
    min: "15"
    max: "999"
mainContainerStyle:
  backgroundColor: "#ffffff00"
cellStyle:
  minHeight: 10px

```
```contributionGraph
title: طراحی 🎨
graphType: default
dateRangeValue: 180
dateRangeType: FIXED_DATE_RANGE
startOfWeek: "6"
showCellRuleIndicators: true
titleStyle:
  textAlign: center
  fontSize: 18px
  fontWeight: normal
dataSource:
  type: PAGE
  value: "#journal"
  dateField:
    type: FILE_NAME
    value: date
  countField:
    type: PAGE_PROPERTY
    value: 🎨drawing
fillTheScreen: true
enableMainContainerShadow: false
fromDate: شروع
toDate: پایان
cellStyleRules:
  - id: Halloween_a
    color: "#fdd577"
    min: 1
    max: "5"
  - id: Halloween_b
    color: "#faaa53"
    min: "5"
    max: "10"
  - id: Halloween_c
    color: "#f07c44"
    min: "10"
    max: "15"
  - id: Halloween_d
    color: "#d94e49"
    min: "15"
    max: "999"
mainContainerStyle:
  backgroundColor: "#ffffff00"
cellStyle:
  minHeight: 10px

```
```contributionGraph
title: زبان انگلیسی 🌎
graphType: default
dateRangeValue: 180
dateRangeType: FIXED_DATE_RANGE
startOfWeek: "6"
showCellRuleIndicators: true
titleStyle:
  textAlign: center
  fontSize: 18px
  fontWeight: normal
dataSource:
  type: PAGE
  value: "#journal"
  dateField:
    type: FILE_NAME
    value: date
  countField:
    type: PAGE_PROPERTY
    value: 🌎English
fillTheScreen: true
enableMainContainerShadow: false
fromDate: شروع
toDate: پایان
cellStyleRules:
  - id: Halloween_a
    color: "#fdd577"
    min: 1
    max: "5"
  - id: Halloween_b
    color: "#faaa53"
    min: "5"
    max: "10"
  - id: Halloween_c
    color: "#f07c44"
    min: "10"
    max: "15"
  - id: Halloween_d
    color: "#d94e49"
    min: "15"
    max: 9999
mainContainerStyle:
  backgroundColor: "#ffffff00"
cellStyle:
  minHeight: 10px

```
‌
‌
‌
‌
# 📱 سوشال مدیا
```contributionGraph
title: ""
graphType: default
dateRangeValue: 180
dateRangeType: FIXED_DATE_RANGE
startOfWeek: "6"
showCellRuleIndicators: true
titleStyle:
  textAlign: left
  fontSize: 15px
  fontWeight: normal
dataSource:
  type: PAGE
  value: "#journal"
  dateField:
    type: FILE_NAME
    value: date
  countField:
    type: PAGE_PROPERTY
    value: 📱social
fillTheScreen: true
enableMainContainerShadow: false
fromDate: شروع
toDate: پایان
cellStyleRules:
  - id: Ocean_a
    color: "#c0e1ffff"
    min: 1
    max: "2"
  - id: Ocean_b
    color: "#5fbfffff"
    min: "2"
    max: "3"
  - id: Ocean_c
    color: "#0784e4ff"
    min: "3"
    max: "4"
  - id: Ocean_d
    color: "#0760a9ff"
    min: "4"
    max: "5"
  - id: 1713257815258
    min: "5"
    max: "24"
    color: "#083864ff"
    text: ""
cellStyle:
  minHeight: 15px

```
```tracker
searchType: frontmatter
searchTarget: 📱social
startDate: شروع
endDate: پایان
folder: journal
summary:
    template: "🔘  جمع کل: ‌ ‌{{sum()}} ساعت\n🔺 بیشترین: ‌ ‌{{max()}} ساعت\n🔻 کمترین: ‌ ‌{{min()}} ساعت\n📈 میانگین: ‌ ‌{{average()}} ساعت"
```
‌‌
> [!quote]- نمودار
> 
> ``` tracker
> searchType: frontmatter
> searchTarget: 📱social
> startDate: شروع
> endDate: پایان
> folder: journal
> aspectRatio: 18:9
> bar:
>     title: " "
>     xAxisLabel: " "
>     yAxisLabel: " "
> 	yMin: 8
> 	yMax: 0
> 	barColor: "#63b2f5"
> ```


